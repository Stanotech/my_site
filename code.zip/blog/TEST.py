posts = {

    "post1": {
        "title": "Mountains",
        "photo": "fsdfdsa/sdafas",
        "content": "FAJNIE SIE CHODZI"

    },
    "post1": {
        "title": "shopping",
        "photo": "fsdsdsa/sdafas",
        "content": "FAJNIE SIE kupuje"

    },    
}


zmienna = "post1"

print(posts[zmienna]["title"])